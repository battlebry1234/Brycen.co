# PlayZone – Games • Movies • Music

A simple single-page entertainment website with:

- Fully playable browser games (COD-style shooter, Arena Fighter, Button Mash, Combo Trainer, Snake, Memory Match)
- Official Call of Duty Mobile download links
- Full public-domain movies you can watch directly on the page
- Modern movie trailers + legal “Where to Watch” links
- Free playable music playlist

## How to run on GitHub Pages

1. Create a new repository on GitHub (public).
2. Upload these three files to the root of the repository:
   - `index.html`
   - `README.md`
   - `LICENSE`
3. Go to **Settings → Pages**.
4. Under **Source**, choose **Deploy from a branch**.
5. Select branch `main` (or `master`) and folder `/ (root)`.
6. Click **Save**.
7. After a minute or two your site will be live at:  
   `https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/`

## Local testing

Just open `index.html` in any modern browser.

## Notes

- All games run entirely in the browser (no server needed).
- Movies that play on the page are public-domain only.
- Modern movies show trailers and link to legal streaming options.
- Music tracks are free algorithmic examples from SoundHelix.
